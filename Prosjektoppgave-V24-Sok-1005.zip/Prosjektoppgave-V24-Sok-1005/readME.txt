### Instrukser for Sok-1005-prosjektoppgave """

Authors: Kandidatnummer 40 & Kandidatnummer 18
-----------------------------------------------------------------------

Prosjektoppgaven vil komme med 2 filer. 1 .ipynb fil og 1 .qmd fil.

Det er forventet at datasettene 'NSD2995-V2.csv' og 'NSD3106-V1.csv' har samme filplasering som .ipynb og .qmd filene.

-----------------------------------------------------------------------
#### Steg for å kjøre filene ###

Steg 1:
- Kjør .ipynb filen.

Denne filen inneholder all koden som sorterer og filtrerer data.
Denne filen tar de originale .csv filene 'NSD2995-V2.csv' og 'NSD3106-V1.csv' og sorterer dem.
Etter du har kjørt filen vil du ende opp med en ny .csv fil som heter 'full_data.csv'

Steg 2:
- Kjør .qmd filen.

.qmd filen er dokumentet som inneholder selve analysen og grafene og liknende kalkulasjoner bruker datasettet 'full_data.csv' for å fungere ordentlig.